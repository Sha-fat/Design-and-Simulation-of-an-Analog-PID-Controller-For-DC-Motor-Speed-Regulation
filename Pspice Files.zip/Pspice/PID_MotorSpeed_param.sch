*version 9.2 523400717
u 562
U? 9
C? 5
R? 16
F? 3
E? 3
Q? 5
PM? 2
@libraries
@analysis
.TRAN 1 0 0 0
+0 1m
+1 10
+3 1m
.STEP 1 3 4
+ 0 RFP
+ -1 100k,400k,900k,1200k
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 19921 
@status
n 0 126:08:23:21:34:38;1790177678 e 
s 2832 126:08:23:21:34:39;1790177679 e 
c 126:08:23:21:34:36;1790177676
*page 1 0 1520 970 iB
@ports
port 313 gnd_analog 260 230 h
port 314 bubble 650 180 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=P_OUT
port 315 gnd_analog 510 200 h
port 316 bubble 470 160 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 317 bubble 380 160 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=ERROR
port 318 gnd_analog 250 440 h
port 319 gnd_analog 1100 220 h
port 320 bubble 1010 180 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 321 bubble 1240 200 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=D_OUT
port 322 gnd_analog 1050 390 d
a 1 s 3 0 18 22 hln 100 LABEL=0
port 323 gnd_analog 1170 340 h
a 1 s 3 0 18 22 hln 100 LABEL=0
port 324 gnd_analog 1000 330 u
a 1 s 3 0 18 22 hln 100 LABEL=0
port 325 bubble 1170 330 h
a 1 x 3 0 0 0 hcn 100 LABEL=SPEED
port 326 gnd_analog 1060 510 h
a 1 s 3 0 18 22 hln 100 LABEL=0
port 327 gnd_analog 1130 480 h
port 328 bubble 1130 440 h
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 329 bubble 1170 440 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 330 gnd_analog 1170 480 h
port 331 gnd_analog 800 230 h
port 332 bubble 930 210 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=I_OUT
port 333 bubble 860 150 h
a 1 x 3 0 20 10 hcn 100 LABEL=V-
port 334 gnd_analog 180 230 h
port 335 bubble 310 200 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 336 bubble 310 140 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 337 bubble 570 210 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 338 bubble 570 150 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 339 bubble 860 240 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 340 bubble 1160 230 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 341 bubble 1160 170 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 342 bubble 310 450 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 343 bubble 310 390 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 344 bubble 750 190 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 345 bubble 170 350 v
a 1 x 3 0 20 12 hcn 100 LABEL=P_OUT
port 346 bubble 170 390 v
a 1 x 3 0 18 8 hcn 100 LABEL=I_OUT
port 347 bubble 170 430 v
a 1 x 3 0 20 10 hcn 100 LABEL=D_OUT
port 348 bubble 390 420 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=CTRL
port 349 bubble 180 80 v
a 1 x 3 0 32 22 hcn 100 LABEL=SPEED
port 350 bubble 1060 410 d
a 1 x 3 0 4 -30 hcn 100 LABEL=SPEED
port 351 bubble 850 340 v
a 1 x 3 0 0 0 hcn 100 LABEL=VMOTOR
port 352 bubble 860 470 d
a 1 x 3 0 6 0 hcn 100 LABEL=CTRL
port 353 bubble 640 560 u
a 1 x 3 0 0 0 hcn 100 LABEL=VMOTOR
port 354 bubble 460 470 v
a 1 x 3 0 6 0 hcn 100 LABEL=CTRL
port 355 bubble 580 340 h
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 356 bubble 700 340 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
@parts
part 273 r 300 80 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R2Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R2Rf
part 274 r 260 230 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 11 37 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R4
a 0 xp 9 0 15 0 hln 100 REFDES=R4
part 275 r 470 160 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R5Rin
a 0 xp 9 0 15 0 hln 100 REFDES=R5Rin
part 276 f 1050 340 D
a 0 s 11 0 10 34 hln 100 PART=f
a 0 u 0 0 0 10 hln 100 GAIN=0.05
a 0 a 0:13 0 0 0 hln 100 PKGREF=F2
a 1 ap 9 0 10 4 hln 100 REFDES=F2
part 277 E 1170 330 H
a 0 s 11 0 10 34 hln 100 PART=E
a 0 u 0 0 0 10 hln 100 GAIN=0.05
a 0 a 0:13 0 0 0 hln 100 PKGREF=E2
a 1 ap 9 0 10 4 hln 100 REFDES=E2
part 278 Vdc 1130 440 h
a 0 sp 0 0 22 37 hln 100 PART=Vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=V1
a 1 xp 9 0 24 7 hcn 100 REFDES=V1
a 1 u 13 0 -11 18 hcn 100 DC=18
part 279 Vdc 1170 480 u
a 0 sp 0 0 22 37 hln 100 PART=Vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=V2
a 1 xp 9 0 24 7 hcn 100 REFDES=V2
a 1 u 13 0 -11 18 hcn 100 DC=18
part 280 r 1060 180 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R9Rs
a 0 xp 9 0 15 0 hln 100 REFDES=R9Rs
a 0 u 13 0 15 25 hln 100 VALUE=100
part 281 c 1040 470 d
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 25 41 hln 100 VALUE=0.01
a 0 x 0:13 0 0 0 hln 100 PKGREF=C3
a 0 xp 9 0 29 4 hln 100 REFDES=C3
a 0 u 0 0 0 0 hln 100 IC=0
part 284 TL071/301/TI 270 190 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U4
a 0 ap 9 0 10 -2 hln 100 REFDES=U4
part 285 TL071/301/TI 530 200 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U5
a 0 ap 9 0 10 -2 hln 100 REFDES=U5
part 286 TL071/301/TI 820 230 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U6
a 0 ap 9 0 10 -2 hln 100 REFDES=U6
part 287 TL071/301/TI 1120 220 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U7
a 0 ap 9 0 10 -2 hln 100 REFDES=U7
part 288 r 850 70 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100meg
a 0 a 0:13 0 0 0 hln 100 PKGREF=R9
a 0 ap 9 0 15 0 hln 100 REFDES=R9
part 289 r 300 340 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R14Rf
a 0 xp 9 0 33 4 hln 100 REFDES=R14Rf
part 290 TL071/301/TI 270 440 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U8
a 0 ap 9 0 10 -2 hln 100 REFDES=U8
part 291 r 170 350 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 a 0:13 0 0 0 hln 100 PKGREF=R10
a 0 ap 9 0 15 0 hln 100 REFDES=R10
part 292 r 170 390 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 a 0:13 0 0 0 hln 100 PKGREF=R11
a 0 ap 9 0 15 4 hln 100 REFDES=R11
part 293 r 170 430 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 a 0:13 0 0 0 hln 100 PKGREF=R12
a 0 ap 9 0 15 0 hln 100 REFDES=R12
part 294 r 210 190 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R3
a 0 xp 9 0 15 0 hln 100 REFDES=R3
a 0 u 13 0 15 25 hln 100 VALUE=400k
part 295 r 180 80 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R3S
a 0 xp 9 0 15 0 hln 100 REFDES=R3S
a 0 u 13 0 15 25 hln 100 VALUE=400k
part 296 r 850 340 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=2
a 0 x 0:13 0 0 0 hln 100 PKGREF=R17Ra
a 0 xp 9 0 3 -2 hln 100 REFDES=R17Ra
part 297 l 940 340 h
a 0 sp 0 0 0 10 hlb 100 PART=l
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=L2012C
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=L1La
a 0 xp 9 0 15 0 hln 100 REFDES=L1La
a 0 u 13 0 15 25 hln 100 VALUE=20m
part 298 r 620 390 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R13
a 0 ap 9 0 15 0 hln 100 REFDES=R13
part 299 BD204 600 420 u
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-220AB
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 13 46 hln 100 PART=BD204
a 0 x 0:13 0 0 0 hln 100 PKGREF=Q7
a 0 xp 9 0 5 5 hln 100 REFDES=Q7
part 300 BD203 680 420 U
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-220AB
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 15 42 hln 100 PART=BD203
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q3
a 0 ap 9 0 7 15 hln 100 REFDES=Q3
part 301 r 660 400 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R14
a 0 ap 9 0 15 0 hln 100 REFDES=R14
part 302 BD135/PLP 610 470 h
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-126
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=Q6
a 0 xp 9 0 1 6 hln 100 REFDES=Q6
a 0 sp 11 0 -28 44 hln 100 PART=BD135/PLP
part 303 BD136/PLP 680 470 H
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-126
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 -30 40 hln 100 PART=BD136/PLP
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q4
a 0 ap 9 0 1 6 hln 100 REFDES=Q4
part 304 r 750 190 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=66.5k
a 0 a 0:13 0 0 0 hln 100 PKGREF=R15
a 0 ap 9 0 15 0 hln 100 REFDES=R15
part 305 r 490 470 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R15Rbase
a 0 xp 9 0 15 0 hln 100 REFDES=R15Rbase
a 0 u 13 0 15 25 hln 100 VALUE=25
part 306 r 760 470 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R16base
a 0 xp 9 0 15 0 hln 100 REFDES=R16base
a 0 u 13 0 15 25 hln 100 VALUE=25
part 307 r 580 550 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RE1
a 0 xp 9 0 15 0 hln 100 REFDES=RE1
a 0 u 13 0 17 43 hln 100 VALUE=0.05
part 308 r 700 550 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RE2
a 0 xp 9 0 15 0 hln 100 REFDES=RE2
a 0 u 13 0 19 43 hln 100 VALUE=0.05
part 309 r 1080 460 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R19
a 0 xp 9 0 15 0 hln 100 REFDES=R19
a 0 u 13 0 15 31 hln 100 VALUE=100
part 310 r 1150 110 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R10Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R10Rf
a 0 u 13 0 15 25 hln 100 VALUE=40k
part 311 r 560 80 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R6Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R6Rf
a 0 u 13 0 15 25 hln 100 VALUE={RFP}
part 201 param 450 30 h
a 1 ap 0 0 10 -2 hcn 100 REFDES=PM1
a 0 u 13 0 0 20 hln 100 NAME1=RFP
a 0 a 0:13 0 0 0 hln 100 PKGREF=PM1
a 0 u 13 0 50 22 hlb 100 VALUE1=900k
part 312 VPULSE 180 190 h
a 0 x 0:13 0 0 0 hln 100 PKGREF=VREF
a 1 xp 9 0 24 10 hcn 100 REFDES=VREF
a 1 u 0 0 0 0 hcn 100 TR=10m
a 1 u 0 0 0 0 hcn 100 PER=10
a 1 u 0 0 0 0 hcn 100 TF=10m
a 1 u 0 0 0 0 hcn 100 PW=10
a 1 u 0 0 0 0 hcn 100 TD=1n
a 1 u 0 0 0 0 hcn 100 V1=0
a 1 u 0 0 0 0 hcn 100 V2=25
part 283 c 860 110 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=1u
a 0 u 0 0 0 0 hln 100 IC=0
a 0 x 0:13 0 0 0 hln 100 PKGREF=C1
a 0 xp 9 0 15 0 hln 100 REFDES=C1
part 282 c 1010 180 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=1u
a 0 u 0 0 0 0 hln 100 IC=0
a 0 x 0:13 0 0 0 hln 100 PKGREF=C2
a 0 xp 9 0 15 0 hln 100 REFDES=C2
part 1 titleblk 1520 970 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=B
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 357 nodeMarker 1060 410 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=76
@conn
w 360
a 0 sr 3 0 1050 178 hcn 100 LABEL=D_MID
s 1040 180 1060 180 359
a 0 sr 3 0 1050 178 hcn 100 LABEL=D_MID
a 0 up 33 0 1050 179 hct 100 V=
w 362
s 1060 510 1080 510 361
s 1040 510 1060 510 363
s 1040 500 1040 510 365
s 1080 510 1080 500 367
w 370
s 1050 380 1050 390 369
a 0 up 33 0 1052 385 hlt 100 V=
w 372
s 340 80 380 80 371
s 380 80 380 160 373
a 0 up 33 0 382 125 hlt 100 V=
s 380 170 380 160 375
s 380 170 350 170 377
w 380
s 250 190 260 190 379
s 260 190 270 190 381
a 0 up 33 0 265 189 hct 100 V=
w 384
s 520 160 530 160 383
s 520 80 560 80 385
s 520 160 520 80 387
a 0 up 33 0 522 120 hlt 100 V=
s 510 160 520 160 389
w 392
s 510 200 530 200 391
a 0 up 33 0 520 199 hct 100 V=
w 394
s 650 80 650 180 393
a 0 up 33 0 652 130 hlt 100 V=
s 600 80 650 80 395
s 650 180 610 180 397
w 400
s 800 230 820 230 399
a 0 up 33 0 810 229 hct 100 V=
w 402
s 860 180 860 150 401
a 0 up 33 0 862 165 hlt 100 V=
w 404
s 810 70 850 70 409
s 820 190 810 190 407
s 810 190 790 190 413
s 810 70 810 110 411
a 0 up 33 0 812 115 hlt 100 V=
s 810 110 810 190 416
s 860 110 810 110 414
w 418
s 890 70 930 70 421
s 930 210 900 210 419
s 930 70 930 110 423
a 0 up 33 0 932 125 hlt 100 V=
s 930 110 930 210 427
s 890 110 930 110 425
w 429
s 1190 110 1240 110 428
s 1240 200 1200 200 430
s 1240 110 1240 200 432
a 0 up 33 0 1242 155 hlt 100 V=
w 435
s 1110 110 1150 110 434
s 1110 180 1110 110 436
a 0 up 33 0 1112 145 hlt 100 V=
s 1110 180 1120 180 438
s 1100 180 1110 180 440
w 443
s 1100 220 1120 220 442
a 0 up 33 0 1110 219 hct 100 V=
w 445
s 250 440 270 440 444
a 0 up 33 0 260 439 hct 100 V=
w 447
s 340 340 390 340 446
s 390 340 390 420 448
a 0 up 33 0 392 380 hlt 100 V=
s 390 420 350 420 450
w 453
s 300 80 260 80 452
s 260 80 260 150 454
a 0 up 33 0 262 115 hlt 100 V=
s 260 150 270 150 456
s 220 80 260 80 458
w 461
a 0 sr 3 0 915 338 hcn 100 LABEL=A1
s 940 340 890 340 460
a 0 sr 3 0 915 338 hcn 100 LABEL=A1
a 0 up 33 0 915 339 hct 100 V=
w 463
s 1130 330 1000 330 462
a 0 up 33 0 1085 329 hct 100 V=
w 465
s 1060 340 1130 340 464
a 0 up 33 0 1095 339 hct 100 V=
w 467
s 1060 380 1060 410 466
s 1040 460 1040 470 468
s 1040 460 1060 460 472
s 1060 460 1080 460 476
s 1060 410 1060 460 474
a 0 up 33 0 1062 435 hlt 100 V=
w 478
s 1000 340 1050 340 477
a 0 up 33 0 1025 339 hct 100 V=
w 480
s 210 430 250 430 479
a 0 up 33 0 220 429 hct 100 V=
s 250 340 300 340 481
a 0 up 33 0 275 339 hct 100 V=
s 250 400 270 400 483
s 250 390 250 400 485
s 210 390 250 390 487
s 250 340 250 350 491
s 250 350 250 390 495
s 210 350 250 350 493
s 250 430 250 400 496
w 499
s 860 470 800 470 498
a 0 up 33 0 845 469 hct 100 V=
w 501
s 490 470 460 470 500
a 0 up 33 0 470 469 hct 100 V=
w 503
s 580 340 580 350 504
a 0 up 33 0 582 370 hlt 100 V=
s 580 350 580 400 508
s 580 350 620 350 506
w 510
s 700 510 700 440 509
a 0 up 33 0 702 475 hlt 100 V=
w 512
s 580 430 580 440 511
a 0 up 33 0 582 440 hlt 100 V=
s 580 440 580 510 513
w 516
s 700 400 700 350 519
a 0 up 33 0 702 425 hlt 100 V=
s 660 350 660 360 517
s 700 350 700 340 523
s 660 350 700 350 521
w 525
s 630 420 630 450 524
s 630 420 620 420 528
s 620 420 600 420 532
s 620 390 620 420 530
a 0 up 33 0 622 405 hlt 100 V=
w 534
s 530 470 610 470 533
a 0 up 33 0 530 469 hct 100 V=
w 536
s 680 470 760 470 535
a 0 up 33 0 750 469 hct 100 V=
w 538
s 630 560 640 560 539
s 630 490 630 560 543
s 580 560 580 550 545
s 580 560 630 560 547
a 0 up 33 0 665 559 hct 100 V=
s 700 560 700 550 541
s 640 560 660 560 549
s 660 560 700 560 553
s 660 490 660 560 551
w 555
s 680 420 660 420 554
s 660 420 660 450 556
a 0 up 33 0 662 435 hlt 100 V=
s 660 400 660 420 558
w 561
s 180 190 210 190 560
a 0 up 33 0 190 189 hct 100 V=
@junction
j 260 230
+ s 313
+ p 274 1
j 470 160
+ s 316
+ p 275 1
j 1010 180
+ s 320
+ p 282 1
j 1170 340
+ s 323
+ p 277 2
j 1170 330
+ s 325
+ p 277 1
j 1130 480
+ s 327
+ p 278 -
j 1130 440
+ s 328
+ p 278 +
j 1170 440
+ s 329
+ p 279 -
j 1170 480
+ s 330
+ p 279 +
j 180 230
+ s 334
+ p 312 -
j 310 200
+ s 335
+ p 284 V+
j 310 140
+ s 336
+ p 284 V-
j 570 210
+ s 337
+ p 285 V+
j 570 150
+ s 338
+ p 285 V-
j 860 240
+ s 339
+ p 286 V+
j 1160 230
+ s 340
+ p 287 V+
j 1160 170
+ s 341
+ p 287 V-
j 310 450
+ s 342
+ p 290 V+
j 310 390
+ s 343
+ p 290 V-
j 750 190
+ s 344
+ p 304 1
j 170 350
+ s 345
+ p 291 1
j 170 390
+ s 346
+ p 292 1
j 170 430
+ s 347
+ p 293 1
j 180 80
+ s 349
+ p 295 1
j 850 340
+ s 351
+ p 296 1
j 1060 410
+ p 357 pin1
+ s 350
j 1060 180
+ p 280 1
+ w 360
j 1040 180
+ p 282 2
+ w 360
j 1060 510
+ s 326
+ w 362
j 1040 500
+ p 281 2
+ w 362
j 1080 500
+ p 309 2
+ w 362
j 1050 380
+ p 276 3
+ w 370
j 1050 390
+ s 322
+ w 370
j 340 80
+ p 273 2
+ w 372
j 380 160
+ s 317
+ w 372
j 350 170
+ p 284 OUT
+ w 372
j 260 190
+ p 274 2
+ w 380
j 250 190
+ p 294 2
+ w 380
j 270 190
+ p 284 +
+ w 380
j 530 160
+ p 285 -
+ w 384
j 560 80
+ p 311 1
+ w 384
j 510 160
+ p 275 2
+ w 384
j 520 160
+ w 384
+ w 384
j 530 200
+ p 285 +
+ w 392
j 510 200
+ s 315
+ w 392
j 650 180
+ s 314
+ w 394
j 600 80
+ p 311 2
+ w 394
j 610 180
+ p 285 OUT
+ w 394
j 820 230
+ p 286 +
+ w 400
j 800 230
+ s 331
+ w 400
j 860 180
+ p 286 V-
+ w 402
j 860 150
+ s 333
+ w 402
j 850 70
+ p 288 1
+ w 404
j 820 190
+ p 286 -
+ w 404
j 790 190
+ p 304 2
+ w 404
j 810 190
+ w 404
+ w 404
j 860 110
+ p 283 1
+ w 404
j 810 110
+ w 404
+ w 404
j 890 70
+ p 288 2
+ w 418
j 900 210
+ p 286 OUT
+ w 418
j 930 210
+ s 332
+ w 418
j 890 110
+ p 283 2
+ w 418
j 930 110
+ w 418
+ w 418
j 1190 110
+ p 310 2
+ w 429
j 1200 200
+ p 287 OUT
+ w 429
j 1240 200
+ s 321
+ w 429
j 1150 110
+ p 310 1
+ w 435
j 1120 180
+ p 287 -
+ w 435
j 1100 180
+ p 280 2
+ w 435
j 1110 180
+ w 435
+ w 435
j 1120 220
+ p 287 +
+ w 443
j 1100 220
+ s 319
+ w 443
j 270 440
+ p 290 +
+ w 445
j 250 440
+ s 318
+ w 445
j 340 340
+ p 289 2
+ w 447
j 390 420
+ s 348
+ w 447
j 350 420
+ p 290 OUT
+ w 447
j 300 80
+ p 273 1
+ w 453
j 270 150
+ p 284 -
+ w 453
j 220 80
+ p 295 2
+ w 453
j 260 80
+ w 453
+ w 453
j 890 340
+ p 296 2
+ w 461
j 940 340
+ p 297 1
+ w 461
j 1130 330
+ p 277 3
+ w 463
j 1000 330
+ s 324
+ w 463
j 1060 340
+ p 276 2
+ w 465
j 1130 340
+ p 277 4
+ w 465
j 1060 380
+ p 276 4
+ w 467
j 1060 410
+ s 350
+ w 467
j 1060 410
+ p 357 pin1
+ w 467
j 1040 470
+ p 281 1
+ w 467
j 1080 460
+ p 309 1
+ w 467
j 1060 460
+ w 467
+ w 467
j 1050 340
+ p 276 1
+ w 478
j 1000 340
+ p 297 2
+ w 478
j 210 430
+ p 293 2
+ w 480
j 250 390
+ w 480
+ w 480
j 250 350
+ w 480
+ w 480
j 300 340
+ p 289 1
+ w 480
j 270 400
+ p 290 -
+ w 480
j 210 390
+ p 292 2
+ w 480
j 210 350
+ p 291 2
+ w 480
j 250 400
+ w 480
+ w 480
j 800 470
+ p 306 2
+ w 499
j 860 470
+ s 352
+ w 499
j 490 470
+ p 305 1
+ w 501
j 460 470
+ s 354
+ w 501
j 580 340
+ s 355
+ w 503
j 580 400
+ p 299 e
+ w 503
j 620 350
+ p 298 2
+ w 503
j 580 350
+ w 503
+ w 503
j 700 440
+ p 300 c
+ w 510
j 700 510
+ p 308 2
+ w 510
j 580 440
+ p 299 c
+ w 512
j 580 510
+ p 307 2
+ w 512
j 700 400
+ p 300 e
+ w 516
j 700 340
+ s 356
+ w 516
j 660 360
+ p 301 2
+ w 516
j 700 350
+ w 516
+ w 516
j 630 450
+ p 302 C
+ w 525
j 600 420
+ p 299 b
+ w 525
j 620 390
+ p 298 1
+ w 525
j 620 420
+ w 525
+ w 525
j 610 470
+ p 302 B
+ w 534
j 530 470
+ p 305 2
+ w 534
j 680 470
+ p 303 B
+ w 536
j 760 470
+ p 306 1
+ w 536
j 640 560
+ s 353
+ w 538
j 630 490
+ p 302 E
+ w 538
j 580 550
+ p 307 1
+ w 538
j 630 560
+ w 538
+ w 538
j 700 550
+ p 308 1
+ w 538
j 660 490
+ p 303 E
+ w 538
j 660 560
+ w 538
+ w 538
j 680 420
+ p 300 b
+ w 555
j 660 450
+ p 303 C
+ w 555
j 660 400
+ p 301 1
+ w 555
j 660 420
+ w 555
+ w 555
j 210 190
+ p 294 1
+ w 561
j 180 190
+ p 312 +
+ w 561
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=B
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
t 266 t 6 500 270 610 300 0 25
Proportional stage (U2)

t 267 t 6 320 300 220 270 0 33
Error / difference amplifier (U1)
t 268 t 6 1120 270 1240 300 0 21
Derivative stage (U4)
t 269 t 6 220 500 320 530 0 22
Summing amplifier (U5)
t 270 t 6 920 540 1200 560 0 50
 Motor R-L-E branch and mechanical analog (E1, F1)
t 271 t 6 790 280 910 310 0 22
 Integral stage (U3)

t 272 t 6 560 590 700 610 0 18
Power stage driver
