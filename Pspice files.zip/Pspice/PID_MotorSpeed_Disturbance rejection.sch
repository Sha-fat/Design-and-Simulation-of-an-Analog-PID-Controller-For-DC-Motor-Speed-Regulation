*version 9.2 99488906
u 585
U? 9
F? 3
E? 3
Q? 5
PM? 2
I? 2
? 4
C? 3
R? 8
@libraries
@analysis
.TRAN 1 0 0 0
+0 1m
+1 25
+3 1m
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 21787 
@status
n 0 126:08:25:14:34:03;1790325243 e 
s 2832 126:08:25:14:34:03;1790325243 e 
*page 1 0 1520 970 iB
@ports
port 324 gnd_analog 300 290 h
port 325 bubble 690 240 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=P_OUT
port 326 gnd_analog 550 260 h
port 327 bubble 510 220 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 328 bubble 420 220 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=ERROR
port 329 gnd_analog 290 500 h
port 330 gnd_analog 1140 280 h
port 331 bubble 1050 240 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 332 bubble 1280 260 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=D_OUT
port 333 gnd_analog 1090 450 d
a 1 s 3 0 18 22 hln 100 LABEL=0
port 334 gnd_analog 1210 400 h
a 1 s 3 0 18 22 hln 100 LABEL=0
port 335 gnd_analog 1040 390 u
a 1 s 3 0 18 22 hln 100 LABEL=0
port 336 bubble 1210 390 h
a 1 x 3 0 0 0 hcn 100 LABEL=SPEED
port 337 gnd_analog 1100 570 h
a 1 s 3 0 18 22 hln 100 LABEL=0
port 342 gnd_analog 840 290 h
port 343 bubble 970 270 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=I_OUT
port 344 bubble 900 210 h
a 1 x 3 0 20 10 hcn 100 LABEL=V-
port 345 gnd_analog 220 290 h
port 346 bubble 350 260 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 347 bubble 350 200 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 348 bubble 610 270 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 349 bubble 610 210 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 350 bubble 900 300 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 351 bubble 1200 290 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 352 bubble 1200 230 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 353 bubble 350 510 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 354 bubble 350 450 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 355 bubble 790 250 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 356 bubble 210 410 v
a 1 x 3 0 20 12 hcn 100 LABEL=P_OUT
port 357 bubble 210 450 v
a 1 x 3 0 18 8 hcn 100 LABEL=I_OUT
port 358 bubble 210 490 v
a 1 x 3 0 20 10 hcn 100 LABEL=D_OUT
port 359 bubble 430 480 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=CTRL
port 360 bubble 220 140 v
a 1 x 3 0 32 22 hcn 100 LABEL=SPEED
port 361 bubble 1100 470 d
a 1 x 3 0 4 -30 hcn 100 LABEL=SPEED
port 362 bubble 890 400 v
a 1 x 3 0 0 0 hcn 100 LABEL=VMOTOR
port 364 bubble 680 620 u
a 1 x 3 0 0 0 hcn 100 LABEL=VMOTOR
port 365 bubble 500 530 v
a 1 x 3 0 6 0 hcn 100 LABEL=CTRL
port 366 bubble 620 400 h
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 367 bubble 740 400 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 338 gnd_analog 1270 540 h
port 339 bubble 1270 500 h
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 340 bubble 1310 500 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 341 gnd_analog 1310 540 h
port 363 bubble 900 530 d
a 1 x 3 0 -4 8 hcn 100 LABEL=CTRL
@parts
part 284 r 340 140 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R2Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R2Rf
part 285 r 300 290 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 11 37 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R4
a 0 xp 9 0 15 0 hln 100 REFDES=R4
part 286 r 510 220 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R5Rin
a 0 xp 9 0 15 0 hln 100 REFDES=R5Rin
part 287 f 1090 400 D
a 0 s 11 0 10 34 hln 100 PART=f
a 0 u 0 0 0 10 hln 100 GAIN=0.05
a 0 a 0:13 0 0 0 hln 100 PKGREF=F2
a 1 ap 9 0 10 4 hln 100 REFDES=F2
part 288 E 1210 390 H
a 0 s 11 0 10 34 hln 100 PART=E
a 0 u 0 0 0 10 hln 100 GAIN=0.05
a 0 a 0:13 0 0 0 hln 100 PKGREF=E2
a 1 ap 9 0 10 4 hln 100 REFDES=E2
part 291 r 1100 240 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R9Rs
a 0 xp 9 0 15 0 hln 100 REFDES=R9Rs
a 0 u 13 0 15 25 hln 100 VALUE=100
part 292 c 1080 530 d
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 25 41 hln 100 VALUE=0.01
a 0 x 0:13 0 0 0 hln 100 PKGREF=C3
a 0 xp 9 0 29 4 hln 100 REFDES=C3
a 0 u 0 0 0 0 hln 100 IC=0
part 293 c 1050 240 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=1u
a 0 u 0 0 0 0 hln 100 IC=0
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
part 294 c 900 170 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=1u
a 0 u 0 0 0 0 hln 100 IC=0
a 0 a 0:13 0 0 0 hln 100 PKGREF=C2
a 0 ap 9 0 15 0 hln 100 REFDES=C2
part 295 TL071/301/TI 310 250 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U4
a 0 ap 9 0 10 -2 hln 100 REFDES=U4
part 296 TL071/301/TI 570 260 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U5
a 0 ap 9 0 10 -2 hln 100 REFDES=U5
part 297 TL071/301/TI 860 290 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U6
a 0 ap 9 0 10 -2 hln 100 REFDES=U6
part 298 TL071/301/TI 1160 280 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U7
a 0 ap 9 0 10 -2 hln 100 REFDES=U7
part 299 r 890 130 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100meg
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 300 r 340 400 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R14Rf
a 0 xp 9 0 33 4 hln 100 REFDES=R14Rf
part 301 TL071/301/TI 310 500 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U8
a 0 ap 9 0 10 -2 hln 100 REFDES=U8
part 305 r 250 250 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R3
a 0 xp 9 0 15 0 hln 100 REFDES=R3
a 0 u 13 0 15 25 hln 100 VALUE=400k
part 306 r 220 140 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R3S
a 0 xp 9 0 15 0 hln 100 REFDES=R3S
a 0 u 13 0 15 25 hln 100 VALUE=400k
part 307 r 890 400 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=2
a 0 x 0:13 0 0 0 hln 100 PKGREF=R17Ra
a 0 xp 9 0 3 -2 hln 100 REFDES=R17Ra
part 308 l 980 400 h
a 0 sp 0 0 0 10 hlb 100 PART=l
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=L2012C
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=L1La
a 0 xp 9 0 15 0 hln 100 REFDES=L1La
a 0 u 13 0 15 25 hln 100 VALUE=20m
part 309 r 660 450 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 310 BD204 640 480 u
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-220AB
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 13 46 hln 100 PART=BD204
a 0 x 0:13 0 0 0 hln 100 PKGREF=Q7
a 0 xp 9 0 5 5 hln 100 REFDES=Q7
part 311 BD203 720 480 U
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-220AB
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 15 42 hln 100 PART=BD203
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q3
a 0 ap 9 0 7 15 hln 100 REFDES=Q3
part 312 r 700 460 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R6
a 0 ap 9 0 15 0 hln 100 REFDES=R6
part 313 BD135/PLP 650 530 h
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-126
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=Q6
a 0 xp 9 0 1 6 hln 100 REFDES=Q6
a 0 sp 11 0 -28 44 hln 100 PART=BD135/PLP
part 314 BD136/PLP 720 530 H
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-126
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 -30 40 hln 100 PART=BD136/PLP
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q4
a 0 ap 9 0 1 6 hln 100 REFDES=Q4
part 315 r 790 250 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 ap 9 0 15 0 hln 100 REFDES=R7
a 0 u 13 0 15 25 hln 100 VALUE=66.5k
a 0 a 0:13 0 0 0 hln 100 PKGREF=R7
part 316 r 530 530 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R15Rbase
a 0 xp 9 0 15 0 hln 100 REFDES=R15Rbase
a 0 u 13 0 15 25 hln 100 VALUE=25
part 317 r 800 530 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R16base
a 0 xp 9 0 15 0 hln 100 REFDES=R16base
a 0 u 13 0 15 25 hln 100 VALUE=25
part 318 r 620 610 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RE1
a 0 xp 9 0 15 0 hln 100 REFDES=RE1
a 0 u 13 0 17 43 hln 100 VALUE=0.05
part 319 r 740 610 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RE2
a 0 xp 9 0 15 0 hln 100 REFDES=RE2
a 0 u 13 0 19 43 hln 100 VALUE=0.05
part 321 r 1190 170 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R10Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R10Rf
a 0 u 13 0 15 25 hln 100 VALUE=40k
part 289 Vdc 1270 500 h
a 0 sp 0 0 22 37 hln 100 PART=Vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=V1
a 1 xp 9 0 24 7 hcn 100 REFDES=V1
a 1 u 13 0 -11 18 hcn 100 DC=18
part 290 Vdc 1310 540 u
a 0 sp 0 0 22 37 hln 100 PART=Vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=V2
a 1 xp 9 0 24 7 hcn 100 REFDES=V2
a 1 u 13 0 -11 18 hcn 100 DC=18
part 320 r 1120 520 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R19
a 0 xp 9 0 15 0 hln 100 REFDES=R19
a 0 u 13 0 15 31 hln 100 VALUE=100
part 323 VPULSE 220 250 h
a 0 x 0:13 0 0 0 hln 100 PKGREF=VREF
a 1 xp 9 0 24 10 hcn 100 REFDES=VREF
a 1 u 0 0 0 0 hcn 100 TR=10m
a 1 u 0 0 0 0 hcn 100 TF=10m
a 1 u 0 0 0 0 hcn 100 TD=1n
a 1 u 0 0 0 0 hcn 100 V1=0
a 1 u 0 0 0 0 hcn 100 V2=20
a 1 u 0 0 0 0 hcn 100 PW=25
a 1 u 0 0 0 0 hcn 100 PER=25
part 302 r 210 410 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R11
a 0 xp 9 0 15 0 hln 100 REFDES=R11
part 303 r 210 450 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R12
a 0 xp 9 0 15 4 hln 100 REFDES=R12
part 304 r 210 490 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R13
a 0 xp 9 0 15 0 hln 100 REFDES=R13
part 322 r 600 140 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R6Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R6Rf
a 0 u 13 0 15 25 hln 100 VALUE=950k
part 255 ipulse 1150 530 h
a 0 a 0:13 0 0 0 hln 100 PKGREF=I1
a 1 ap 9 0 20 10 hcn 100 REFDES=I1
a 1 u 0 0 0 0 hcn 100 I1=0
a 1 u 0 0 0 0 hcn 100 TD=10
a 1 u 0 0 0 0 hcn 100 PW=15
a 1 u 0 0 0 0 hcn 100 PER=25
a 1 u 0 0 0 0 hcn 100 TR=10m
a 1 u 0 0 0 0 hcn 100 TF=10m
a 1 u 0 0 0 0 hcn 100 I2=80m
part 1 titleblk 1520 970 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=B
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 368 nodeMarker 1100 470 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=76
part 369 nodeMarker 220 250 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=77
@conn
w 371
a 0 sr 3 0 1090 238 hcn 100 LABEL=D_MID
a 0 up 0:33 0 0 0 hln 100 V=
s 1080 240 1100 240 370
a 0 sr 3 0 1090 238 hcn 100 LABEL=D_MID
a 0 up 33 0 1090 239 hct 100 V=
w 381
a 0 up 0:33 0 0 0 hln 100 V=
s 1090 440 1090 450 380
a 0 up 33 0 1092 445 hlt 100 V=
w 383
a 0 up 0:33 0 0 0 hln 100 V=
s 380 140 420 140 382
s 420 140 420 220 384
a 0 up 33 0 422 185 hlt 100 V=
s 420 230 420 220 386
s 420 230 390 230 388
w 391
a 0 up 0:33 0 0 0 hln 100 V=
s 290 250 300 250 390
s 300 250 310 250 392
a 0 up 33 0 305 249 hct 100 V=
w 395
a 0 up 0:33 0 0 0 hln 100 V=
s 560 220 570 220 394
s 560 140 600 140 396
s 560 220 560 140 398
a 0 up 33 0 562 180 hlt 100 V=
s 550 220 560 220 400
w 403
a 0 up 0:33 0 0 0 hln 100 V=
s 550 260 570 260 402
a 0 up 33 0 560 259 hct 100 V=
w 405
a 0 up 0:33 0 0 0 hln 100 V=
s 690 140 690 240 404
a 0 up 33 0 692 190 hlt 100 V=
s 640 140 690 140 406
s 690 240 650 240 408
w 411
a 0 up 0:33 0 0 0 hln 100 V=
s 840 290 860 290 410
a 0 up 33 0 850 289 hct 100 V=
w 413
a 0 up 0:33 0 0 0 hln 100 V=
s 900 240 900 210 412
a 0 up 33 0 902 225 hlt 100 V=
w 415
a 0 up 0:33 0 0 0 hln 100 V=
s 850 130 890 130 420
s 860 250 850 250 418
s 850 250 830 250 424
s 850 130 850 170 422
a 0 up 33 0 852 175 hlt 100 V=
s 850 170 850 250 427
a 0 up 33 0 852 210 hlt 100 V=
s 900 170 850 170 425
w 429
a 0 up 0:33 0 0 0 hln 100 V=
s 930 130 970 130 432
s 970 270 940 270 430
s 970 130 970 170 434
a 0 up 33 0 972 185 hlt 100 V=
s 970 170 970 270 438
a 0 up 33 0 972 220 hlt 100 V=
s 930 170 970 170 436
w 440
a 0 up 0:33 0 0 0 hln 100 V=
s 1230 170 1280 170 439
s 1280 260 1240 260 441
s 1280 170 1280 260 443
a 0 up 33 0 1282 215 hlt 100 V=
w 446
a 0 up 0:33 0 0 0 hln 100 V=
s 1150 170 1190 170 445
s 1150 240 1150 170 447
a 0 up 33 0 1152 205 hlt 100 V=
s 1150 240 1160 240 449
s 1140 240 1150 240 451
w 454
a 0 up 0:33 0 0 0 hln 100 V=
s 1140 280 1160 280 453
a 0 up 33 0 1150 279 hct 100 V=
w 456
a 0 up 0:33 0 0 0 hln 100 V=
s 290 500 310 500 455
a 0 up 33 0 300 499 hct 100 V=
w 458
a 0 up 0:33 0 0 0 hln 100 V=
s 380 400 430 400 457
s 430 400 430 480 459
a 0 up 33 0 432 440 hlt 100 V=
s 430 480 390 480 461
w 464
a 0 up 0:33 0 0 0 hln 100 V=
s 340 140 300 140 463
s 300 140 300 210 465
a 0 up 33 0 302 175 hlt 100 V=
s 300 210 310 210 467
s 260 140 300 140 469
w 472
a 0 sr 3 0 955 398 hcn 100 LABEL=A1
a 0 up 0:33 0 0 0 hln 100 V=
s 980 400 930 400 471
a 0 sr 3 0 955 398 hcn 100 LABEL=A1
a 0 up 33 0 955 399 hct 100 V=
w 474
a 0 up 0:33 0 0 0 hln 100 V=
s 1170 390 1040 390 473
a 0 up 33 0 1125 389 hct 100 V=
w 476
a 0 up 0:33 0 0 0 hln 100 V=
s 1100 400 1170 400 475
a 0 up 33 0 1135 399 hct 100 V=
w 489
a 0 up 0:33 0 0 0 hln 100 V=
s 1040 400 1090 400 488
a 0 up 33 0 1065 399 hct 100 V=
w 491
a 0 up 0:33 0 0 0 hln 100 V=
s 250 490 290 490 490
a 0 up 33 0 260 489 hct 100 V=
s 290 400 340 400 492
a 0 up 33 0 315 399 hct 100 V=
s 290 460 310 460 494
s 290 450 290 460 496
s 250 450 290 450 498
s 290 400 290 410 502
s 290 410 290 450 506
s 250 410 290 410 504
s 290 490 290 460 507
w 510
a 0 up 0:33 0 0 0 hln 100 V=
s 900 530 840 530 509
a 0 up 33 0 885 529 hct 100 V=
w 512
a 0 up 0:33 0 0 0 hln 100 V=
s 530 530 500 530 511
a 0 up 33 0 510 529 hct 100 V=
w 514
a 0 up 0:33 0 0 0 hln 100 V=
s 620 400 620 410 515
a 0 up 33 0 622 430 hlt 100 V=
s 620 410 620 460 519
a 0 up 33 0 622 435 hlt 100 V=
s 620 410 660 410 517
w 521
a 0 up 0:33 0 0 0 hln 100 V=
s 740 570 740 500 520
a 0 up 33 0 742 535 hlt 100 V=
w 523
a 0 up 0:33 0 0 0 hln 100 V=
s 620 490 620 500 522
a 0 up 33 0 622 500 hlt 100 V=
s 620 500 620 570 524
a 0 up 33 0 622 535 hlt 100 V=
w 527
a 0 up 0:33 0 0 0 hln 100 V=
s 740 460 740 410 530
a 0 up 33 0 742 485 hlt 100 V=
s 700 410 700 420 528
s 740 410 740 400 534
s 700 410 740 410 532
w 536
a 0 up 0:33 0 0 0 hln 100 V=
s 670 480 670 510 535
s 670 480 660 480 539
s 660 480 640 480 543
s 660 450 660 480 541
a 0 up 33 0 662 465 hlt 100 V=
w 545
a 0 up 0:33 0 0 0 hln 100 V=
s 570 530 650 530 544
a 0 up 33 0 570 529 hct 100 V=
w 547
a 0 up 0:33 0 0 0 hln 100 V=
s 720 530 800 530 546
a 0 up 33 0 790 529 hct 100 V=
w 549
a 0 up 0:33 0 0 0 hln 100 V=
s 670 620 680 620 550
s 670 550 670 620 554
s 620 620 620 610 556
s 620 620 670 620 558
a 0 up 33 0 705 619 hct 100 V=
s 740 620 740 610 552
s 680 620 700 620 560
s 700 620 740 620 564
s 700 550 700 620 562
a 0 up 33 0 702 585 hlt 100 V=
w 566
a 0 up 0:33 0 0 0 hln 100 V=
s 720 480 700 480 565
s 700 480 700 510 567
a 0 up 33 0 702 495 hlt 100 V=
s 700 460 700 480 569
w 572
a 0 up 0:33 0 0 0 hln 100 V=
s 220 250 250 250 571
a 0 up 33 0 230 249 hct 100 V=
w 373
s 1100 570 1120 570 372
s 1080 570 1100 570 374
s 1080 560 1080 570 376
s 1120 570 1120 560 378
s 1120 570 1150 570 578
w 478
a 0 up 0:33 0 0 0 hln 100 V=
s 1100 440 1100 470 477
s 1080 520 1080 530 479
s 1080 520 1100 520 483
s 1100 520 1120 520 487
s 1100 470 1100 520 485
a 0 up 33 0 1102 495 hlt 100 V=
s 1150 520 1150 530 577
s 1120 520 1150 520 575
@junction
j 300 290
+ s 324
+ p 285 1
j 510 220
+ s 327
+ p 286 1
j 1050 240
+ s 331
+ p 293 1
j 1210 400
+ s 334
+ p 288 2
j 1210 390
+ s 336
+ p 288 1
j 350 260
+ s 346
+ p 295 V+
j 350 200
+ s 347
+ p 295 V-
j 610 270
+ s 348
+ p 296 V+
j 610 210
+ s 349
+ p 296 V-
j 900 300
+ s 350
+ p 297 V+
j 1200 290
+ s 351
+ p 298 V+
j 1200 230
+ s 352
+ p 298 V-
j 350 510
+ s 353
+ p 301 V+
j 350 450
+ s 354
+ p 301 V-
j 790 250
+ s 355
+ p 315 1
j 210 410
+ s 356
+ p 302 1
j 210 450
+ s 357
+ p 303 1
j 210 490
+ s 358
+ p 304 1
j 220 140
+ s 360
+ p 306 1
j 890 400
+ s 362
+ p 307 1
j 1100 470
+ p 368 pin1
+ s 361
j 1100 240
+ p 291 1
+ w 371
j 1080 240
+ p 293 2
+ w 371
j 1090 440
+ p 287 3
+ w 381
j 1090 450
+ s 333
+ w 381
j 380 140
+ p 284 2
+ w 383
j 420 220
+ s 328
+ w 383
j 390 230
+ p 295 OUT
+ w 383
j 300 250
+ p 285 2
+ w 391
j 290 250
+ p 305 2
+ w 391
j 310 250
+ p 295 +
+ w 391
j 570 220
+ p 296 -
+ w 395
j 600 140
+ p 322 1
+ w 395
j 550 220
+ p 286 2
+ w 395
j 560 220
+ w 395
+ w 395
j 570 260
+ p 296 +
+ w 403
j 550 260
+ s 326
+ w 403
j 690 240
+ s 325
+ w 405
j 640 140
+ p 322 2
+ w 405
j 650 240
+ p 296 OUT
+ w 405
j 860 290
+ p 297 +
+ w 411
j 840 290
+ s 342
+ w 411
j 900 240
+ p 297 V-
+ w 413
j 900 210
+ s 344
+ w 413
j 890 130
+ p 299 1
+ w 415
j 860 250
+ p 297 -
+ w 415
j 830 250
+ p 315 2
+ w 415
j 850 250
+ w 415
+ w 415
j 900 170
+ p 294 1
+ w 415
j 850 170
+ w 415
+ w 415
j 930 130
+ p 299 2
+ w 429
j 940 270
+ p 297 OUT
+ w 429
j 970 270
+ s 343
+ w 429
j 930 170
+ p 294 2
+ w 429
j 970 170
+ w 429
+ w 429
j 1230 170
+ p 321 2
+ w 440
j 1240 260
+ p 298 OUT
+ w 440
j 1280 260
+ s 332
+ w 440
j 1190 170
+ p 321 1
+ w 446
j 1160 240
+ p 298 -
+ w 446
j 1140 240
+ p 291 2
+ w 446
j 1150 240
+ w 446
+ w 446
j 1160 280
+ p 298 +
+ w 454
j 1140 280
+ s 330
+ w 454
j 310 500
+ p 301 +
+ w 456
j 290 500
+ s 329
+ w 456
j 380 400
+ p 300 2
+ w 458
j 430 480
+ s 359
+ w 458
j 390 480
+ p 301 OUT
+ w 458
j 340 140
+ p 284 1
+ w 464
j 310 210
+ p 295 -
+ w 464
j 260 140
+ p 306 2
+ w 464
j 300 140
+ w 464
+ w 464
j 930 400
+ p 307 2
+ w 472
j 980 400
+ p 308 1
+ w 472
j 1170 390
+ p 288 3
+ w 474
j 1040 390
+ s 335
+ w 474
j 1100 400
+ p 287 2
+ w 476
j 1170 400
+ p 288 4
+ w 476
j 1090 400
+ p 287 1
+ w 489
j 1040 400
+ p 308 2
+ w 489
j 250 490
+ p 304 2
+ w 491
j 290 450
+ w 491
+ w 491
j 290 410
+ w 491
+ w 491
j 340 400
+ p 300 1
+ w 491
j 310 460
+ p 301 -
+ w 491
j 250 450
+ p 303 2
+ w 491
j 250 410
+ p 302 2
+ w 491
j 290 460
+ w 491
+ w 491
j 840 530
+ p 317 2
+ w 510
j 900 530
+ s 363
+ w 510
j 530 530
+ p 316 1
+ w 512
j 500 530
+ s 365
+ w 512
j 620 400
+ s 366
+ w 514
j 620 460
+ p 310 e
+ w 514
j 660 410
+ p 309 2
+ w 514
j 620 410
+ w 514
+ w 514
j 740 500
+ p 311 c
+ w 521
j 740 570
+ p 319 2
+ w 521
j 620 500
+ p 310 c
+ w 523
j 620 570
+ p 318 2
+ w 523
j 740 460
+ p 311 e
+ w 527
j 740 400
+ s 367
+ w 527
j 700 420
+ p 312 2
+ w 527
j 740 410
+ w 527
+ w 527
j 670 510
+ p 313 C
+ w 536
j 640 480
+ p 310 b
+ w 536
j 660 450
+ p 309 1
+ w 536
j 660 480
+ w 536
+ w 536
j 650 530
+ p 313 B
+ w 545
j 570 530
+ p 316 2
+ w 545
j 720 530
+ p 314 B
+ w 547
j 800 530
+ p 317 1
+ w 547
j 680 620
+ s 364
+ w 549
j 670 550
+ p 313 E
+ w 549
j 620 610
+ p 318 1
+ w 549
j 670 620
+ w 549
+ w 549
j 740 610
+ p 319 1
+ w 549
j 700 550
+ p 314 E
+ w 549
j 700 620
+ w 549
+ w 549
j 720 480
+ p 311 b
+ w 566
j 700 510
+ p 314 C
+ w 566
j 700 460
+ p 312 1
+ w 566
j 700 480
+ w 566
+ w 566
j 250 250
+ p 305 1
+ w 572
j 220 250
+ p 369 pin1
+ w 572
j 1270 540
+ p 289 -
+ s 338
j 1270 500
+ p 289 +
+ s 339
j 1310 500
+ p 290 -
+ s 340
j 1310 540
+ p 290 +
+ s 341
j 1100 570
+ s 337
+ w 373
j 1080 560
+ p 292 2
+ w 373
j 1120 560
+ p 320 2
+ w 373
j 1120 570
+ w 373
+ w 373
j 1100 440
+ p 287 4
+ w 478
j 1100 470
+ s 361
+ w 478
j 1100 470
+ p 368 pin1
+ w 478
j 1080 530
+ p 292 1
+ w 478
j 1120 520
+ p 320 1
+ w 478
j 1100 520
+ w 478
+ w 478
j 220 290
+ s 345
+ p 323 -
j 220 250
+ p 369 pin1
+ p 323 +
j 220 250
+ p 323 +
+ w 572
j 1150 530
+ p 255 +
+ w 478
j 1150 570
+ p 255 -
+ w 373
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=B
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
t 277 t 6 540 330 650 360 0 25
Proportional stage (U2)

t 278 t 6 360 360 260 330 0 33
Error / difference amplifier (U1)
t 279 t 6 1160 330 1280 360 0 21
Derivative stage (U4)
t 280 t 6 260 560 360 590 0 22
Summing amplifier (U5)
t 281 t 6 960 600 1240 620 0 50
 Motor R-L-E branch and mechanical analog (E1, F1)
t 282 t 6 830 340 950 370 0 22
 Integral stage (U3)

t 283 t 6 600 650 740 670 0 18
Power stage driver
