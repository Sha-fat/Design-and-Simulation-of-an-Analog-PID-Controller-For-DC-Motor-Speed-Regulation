*version 9.2 2685389053
u 1205
V? 9
U? 18
R? 39
C? 4
Q? 12
L? 3
E? 2
F? 3
? 78
D? 16
PM? 2
@libraries
@analysis
.AC 0 3 0
+0 50
+1 0.01
+2 100k
.TRAN 1 0 0 0
+0 1m
+1 10
+3 1m
.STEP 0 3 4
+ 0 RFP
+ -1 90k, 100k, 105k, 120k, 150k, 200k
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 20985 
@status
n 0 126:08:25:12:45:25;1790318725 e 
s 2832 126:08:25:12:45:26;1790318726 e 
c 126:08:25:12:45:24;1790318724
*page 1 0 1520 970 iB
@ports
port 25 gnd_analog 130 220 h
port 78 bubble 520 170 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=P_OUT
port 70 gnd_analog 380 190 h
port 77 bubble 340 150 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 43 bubble 250 150 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=ERROR
port 219 gnd_analog 120 430 h
port 158 gnd_analog 970 210 h
port 179 bubble 880 170 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 180 bubble 1110 190 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=D_OUT
port 259 gnd_analog 920 380 d
a 1 s 3 0 18 22 hln 100 LABEL=0
port 255 gnd_analog 1040 330 h
a 1 s 3 0 18 22 hln 100 LABEL=0
port 254 gnd_analog 870 320 u
a 1 s 3 0 18 22 hln 100 LABEL=0
port 250 bubble 1040 320 h
a 1 x 3 0 0 0 hcn 100 LABEL=SPEED
port 271 gnd_analog 930 500 h
a 1 s 3 0 18 22 hln 100 LABEL=0
port 290 gnd_analog 1000 470 h
port 292 bubble 1000 430 h
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 293 bubble 1040 430 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 291 gnd_analog 1040 470 h
port 129 gnd_analog 670 220 h
port 137 bubble 800 200 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=I_OUT
port 102 bubble 730 140 h
a 1 x 3 0 20 10 hcn 100 LABEL=V-
port 24 gnd_analog 50 220 h
port 44 bubble 180 190 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 45 bubble 180 130 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 54 bubble 440 200 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 53 bubble 440 140 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 103 bubble 730 230 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 157 bubble 1030 220 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 156 bubble 1030 160 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 189 bubble 180 440 u
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 188 bubble 180 380 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
port 461 bubble 620 180 v
a 1 x 3 0 0 10 hcn 100 LABEL=ERROR
port 193 bubble 40 340 v
a 1 x 3 0 20 12 hcn 100 LABEL=P_OUT
port 194 bubble 40 380 v
a 1 x 3 0 18 8 hcn 100 LABEL=I_OUT
port 195 bubble 40 420 v
a 1 x 3 0 20 10 hcn 100 LABEL=D_OUT
port 222 bubble 260 410 d
a 1 x 3 0 -2 -16 hcn 100 LABEL=CTRL
port 692 bubble 50 70 v
a 1 x 3 0 32 22 hcn 100 LABEL=SPEED
port 309 bubble 930 400 d
a 1 x 3 0 4 -30 hcn 100 LABEL=SPEED
port 256 bubble 720 330 v
a 1 x 3 0 0 0 hcn 100 LABEL=VMOTOR
port 696 bubble 730 460 d
a 1 x 3 0 6 0 hcn 100 LABEL=CTRL
port 236 bubble 510 550 u
a 1 x 3 0 0 0 hcn 100 LABEL=VMOTOR
port 695 bubble 330 460 v
a 1 x 3 0 6 0 hcn 100 LABEL=CTRL
port 232 bubble 450 330 h
a 1 x 3 0 0 0 hcn 100 LABEL=V+
port 509 bubble 570 330 h
a 1 x 3 0 0 0 hcn 100 LABEL=V-
@parts
part 7 r 170 70 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R2Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R2Rf
part 6 r 130 220 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 11 37 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R4
a 0 xp 9 0 15 0 hln 100 REFDES=R4
part 55 r 340 150 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R5Rin
a 0 xp 9 0 15 0 hln 100 REFDES=R5Rin
part 257 f 920 330 D
a 0 s 11 0 10 34 hln 100 PART=f
a 0 a 0:13 0 0 0 hln 100 PKGREF=F1
a 1 ap 9 0 10 4 hln 100 REFDES=F1
a 0 u 0 0 0 10 hln 100 GAIN=0.05
part 241 E 1040 320 H
a 0 s 11 0 10 34 hln 100 PART=E
a 0 a 0:13 0 0 0 hln 100 PKGREF=E1
a 1 ap 9 0 10 4 hln 100 REFDES=E1
a 0 u 0 0 0 10 hln 100 GAIN=0.05
part 288 Vdc 1000 430 h
a 0 sp 0 0 22 37 hln 100 PART=Vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=V1
a 1 xp 9 0 24 7 hcn 100 REFDES=V1
a 1 u 13 0 -11 18 hcn 100 DC=18
part 289 Vdc 1040 470 u
a 0 sp 0 0 22 37 hln 100 PART=Vdc
a 0 x 0:13 0 0 0 hln 100 PKGREF=V2
a 1 xp 9 0 24 7 hcn 100 REFDES=V2
a 1 u 13 0 -11 18 hcn 100 DC=18
part 160 r 930 170 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R9Rs
a 0 xp 9 0 15 0 hln 100 REFDES=R9Rs
a 0 u 13 0 15 25 hln 100 VALUE=100
part 261 c 910 460 d
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 25 41 hln 100 VALUE=0.01
a 0 x 0:13 0 0 0 hln 100 PKGREF=C3
a 0 xp 9 0 29 4 hln 100 REFDES=C3
a 0 u 0 0 0 0 hln 100 IC=0
part 159 c 880 170 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C2
a 0 ap 9 0 15 0 hln 100 REFDES=C2
a 0 u 13 0 15 25 hln 100 VALUE=1u
a 0 u 0 0 0 0 hln 100 IC=0
part 106 c 730 100 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
a 0 u 13 0 15 25 hln 100 VALUE=1u
a 0 u 0 0 0 0 hln 100 IC=0
part 931 TL071/301/TI 140 180 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U12
a 0 ap 9 0 10 -2 hln 100 REFDES=U12
part 932 TL071/301/TI 400 190 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U13
a 0 ap 9 0 10 -2 hln 100 REFDES=U13
part 933 TL071/301/TI 690 220 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U14
a 0 ap 9 0 10 -2 hln 100 REFDES=U14
part 934 TL071/301/TI 990 210 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U15
a 0 ap 9 0 10 -2 hln 100 REFDES=U15
part 105 r 720 60 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R8
a 0 ap 9 0 15 0 hln 100 REFDES=R8
a 0 u 13 0 15 25 hln 100 VALUE=100meg
part 196 r 170 330 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=100k
a 0 x 0:13 0 0 0 hln 100 PKGREF=R14Rf
a 0 xp 9 0 33 4 hln 100 REFDES=R14Rf
part 935 TL071/301/TI 140 430 U
a 0 sp 11 0 80 60 hcn 100 PART=TL071/301/TI
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=DIP8
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U16
a 0 ap 9 0 10 -2 hln 100 REFDES=U16
part 190 r 40 340 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R11
a 0 ap 9 0 15 0 hln 100 REFDES=R11
a 0 u 13 0 15 25 hln 100 VALUE=100k
part 191 r 40 380 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R12
a 0 ap 9 0 15 4 hln 100 REFDES=R12
a 0 u 13 0 15 25 hln 100 VALUE=100k
part 192 r 40 420 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R13
a 0 ap 9 0 15 0 hln 100 REFDES=R13
a 0 u 13 0 15 25 hln 100 VALUE=100k
part 5 r 80 180 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R3
a 0 xp 9 0 15 0 hln 100 REFDES=R3
a 0 u 13 0 15 25 hln 100 VALUE=400k
part 960 r 50 70 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R3S
a 0 xp 9 0 15 0 hln 100 REFDES=R3S
a 0 u 13 0 15 25 hln 100 VALUE=400k
part 237 r 720 330 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 25 hln 100 VALUE=2
a 0 x 0:13 0 0 0 hln 100 PKGREF=R17Ra
a 0 xp 9 0 3 -2 hln 100 REFDES=R17Ra
part 238 l 810 330 h
a 0 sp 0 0 0 10 hlb 100 PART=l
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=L2012C
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=L1La
a 0 xp 9 0 15 0 hln 100 REFDES=L1La
a 0 u 13 0 15 25 hln 100 VALUE=20m
part 1121 r 490 380 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R37
a 0 ap 9 0 15 0 hln 100 REFDES=R37
part 1093 BD204 470 410 u
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-220AB
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 13 46 hln 100 PART=BD204
a 0 x 0:13 0 0 0 hln 100 PKGREF=Q7
a 0 xp 9 0 5 5 hln 100 REFDES=Q7
part 1139 BD203 550 410 U
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-220AB
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q9
a 0 sp 11 0 15 42 hln 100 PART=BD203
a 0 ap 9 0 7 15 hln 100 REFDES=Q9
part 1173 r 530 390 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R38
a 0 ap 9 0 15 0 hln 100 REFDES=R38
part 1203 BD135/PLP 480 460 h
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-126
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=Q6
a 0 xp 9 0 1 6 hln 100 REFDES=Q6
a 0 sp 11 0 -28 44 hln 100 PART=BD135/PLP
part 1202 BD136/PLP 550 460 H
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-126
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q11
a 0 ap 9 0 1 6 hln 100 REFDES=Q11
a 0 sp 11 0 -30 40 hln 100 PART=BD136/PLP
part 104 r 620 180 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R7
a 0 ap 9 0 15 0 hln 100 REFDES=R7
a 0 u 13 0 15 25 hln 100 VALUE=66.5k
part 224 r 360 460 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R15Rbase
a 0 xp 9 0 15 0 hln 100 REFDES=R15Rbase
a 0 u 13 0 15 25 hln 100 VALUE=25
part 504 r 630 460 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R16base
a 0 xp 9 0 15 0 hln 100 REFDES=R16base
a 0 u 13 0 15 25 hln 100 VALUE=25
part 512 r 450 540 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RE1
a 0 xp 9 0 15 0 hln 100 REFDES=RE1
a 0 u 13 0 17 43 hln 100 VALUE=0.05
part 514 r 570 540 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RE2
a 0 xp 9 0 15 0 hln 100 REFDES=RE2
a 0 u 13 0 19 43 hln 100 VALUE=0.05
part 262 r 950 450 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R19
a 0 xp 9 0 15 0 hln 100 REFDES=R19
a 0 u 13 0 15 31 hln 100 VALUE=100
part 161 r 1020 100 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R10Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R10Rf
a 0 u 13 0 15 25 hln 100 VALUE=40k
part 56 r 430 70 h
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R6Rf
a 0 xp 9 0 15 0 hln 100 REFDES=R6Rf
a 0 u 13 0 15 25 hln 100 VALUE=950k
part 2 VPULSE 50 180 h
a 0 x 0:13 0 0 0 hln 100 PKGREF=VREF
a 1 xp 9 0 24 10 hcn 100 REFDES=VREF
a 1 u 0 0 0 0 hcn 100 TR=10m
a 1 u 0 0 0 0 hcn 100 PER=10
a 1 u 0 0 0 0 hcn 100 TF=10m
a 1 u 0 0 0 0 hcn 100 V2=30
a 1 u 0 0 0 0 hcn 100 PW=5
a 1 u 0 0 0 0 hcn 100 TD=5
a 1 u 0 0 0 0 hcn 100 V1=20
part 1 titleblk 1520 970 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=B
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 1022 nodeMarker 930 400 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=76
part 1204 nodeMarker 50 180 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=77
@conn
w 163
a 0 up 0:33 0 0 0 hln 100 V=
a 0 sr 0 0 0 0 hln 100 LABEL=D_MID
s 910 170 930 170 162
a 0 sr 3 0 920 168 hcn 100 LABEL=D_MID
a 0 up 33 0 920 169 hct 100 V=
w 831
a 0 up 0:33 0 0 0 hln 100 V=
s 930 500 950 500 840
s 910 500 930 500 267
s 910 490 910 500 265
s 950 500 950 490 269
w 253
a 0 up 0:33 0 0 0 hln 100 V=
s 920 370 920 380 315
a 0 up 33 0 922 375 hlt 100 V=
w 460
a 0 up 0:33 0 0 0 hln 100 V=
s 210 70 250 70 27
s 250 70 250 150 29
a 0 up 33 0 252 115 hlt 100 V=
s 250 160 250 150 354
s 250 160 220 160 31
w 13
a 0 up 0:33 0 0 0 hln 100 V=
s 120 180 130 180 14
s 130 180 140 180 357
a 0 up 33 0 135 179 hct 100 V=
w 73
a 0 up 0:33 0 0 0 hln 100 V=
s 390 150 400 150 85
s 390 70 430 70 62
s 390 150 390 70 59
a 0 up 33 0 392 110 hlt 100 V=
s 380 150 390 150 57
w 84
a 0 up 0:33 0 0 0 hln 100 V=
s 380 190 400 190 79
a 0 up 33 0 390 189 hct 100 V=
w 65
a 0 up 0:33 0 0 0 hln 100 V=
s 520 70 520 170 66
a 0 up 33 0 522 120 hlt 100 V=
s 470 70 520 70 64
s 520 170 480 170 68
w 128
a 0 up 0:33 0 0 0 hln 100 V=
s 670 220 690 220 127
a 0 up 33 0 680 219 hct 100 V=
w 911
a 0 up 0:33 0 0 0 hln 100 V=
s 730 170 730 140 909
a 0 up 33 0 732 155 hlt 100 V=
w 913
a 0 up 0:33 0 0 0 hln 100 V=
s 680 60 680 100 890
a 0 up 33 0 682 105 hlt 100 V=
s 680 180 690 180 107
s 680 180 660 180 396
s 680 60 720 60 121
s 680 100 680 180 927
s 730 100 680 100 443
w 124
a 0 up 0:33 0 0 0 hln 100 V=
s 800 60 800 100 894
a 0 up 33 0 802 115 hlt 100 V=
s 800 200 770 200 117
s 760 60 800 60 123
s 800 100 800 200 924
s 760 100 800 100 445
w 172
a 0 up 0:33 0 0 0 hln 100 V=
s 1060 100 1110 100 171
s 1110 190 1070 190 175
s 1110 100 1110 190 173
a 0 up 33 0 1112 145 hlt 100 V=
w 154
a 0 up 0:33 0 0 0 hln 100 V=
s 980 100 1020 100 169
s 980 170 980 100 166
a 0 up 33 0 982 135 hlt 100 V=
s 980 170 990 170 168
s 970 170 980 170 164
w 152
a 0 up 0:33 0 0 0 hln 100 V=
s 970 210 990 210 151
a 0 up 33 0 980 209 hct 100 V=
w 182
a 0 up 0:33 0 0 0 hln 100 V=
s 120 430 140 430 181
a 0 up 33 0 130 429 hct 100 V=
w 214
a 0 up 0:33 0 0 0 hln 100 V=
s 210 330 260 330 213
s 260 330 260 410 215
a 0 up 33 0 262 370 hlt 100 V=
s 260 410 220 410 217
w 294
a 0 up 0:33 0 0 0 hln 100 V=
s 170 70 130 70 8
s 130 70 130 140 365
a 0 up 33 0 132 105 hlt 100 V=
s 130 140 140 140 367
s 90 70 130 70 985
w 243
a 0 up 0:33 0 0 0 hln 100 V=
a 0 sr 0 0 0 0 hln 100 LABEL=A1
s 810 330 760 330 244
a 0 sr 3 0 785 328 hcn 100 LABEL=A1
a 0 up 33 0 785 329 hct 100 V=
w 543
a 0 up 0:33 0 0 0 hln 100 V=
s 1000 320 870 320 1005
a 0 up 33 0 955 319 hct 100 V=
w 336
a 0 up 0:33 0 0 0 hln 100 V=
s 930 330 1000 330 1007
a 0 up 33 0 965 329 hct 100 V=
w 318
a 0 up 0:33 0 0 0 hln 100 V=
s 930 370 930 400 337
s 910 450 910 460 279
s 910 450 930 450 553
s 930 450 950 450 861
s 930 400 930 450 310
a 0 up 33 0 932 425 hlt 100 V=
w 328
a 0 up 0:33 0 0 0 hln 100 V=
s 870 330 920 330 992
a 0 up 33 0 895 329 hct 100 V=
w 944
a 0 up 0:33 0 0 0 hln 100 V=
s 80 420 120 420 945
a 0 up 33 0 90 419 hct 100 V=
s 120 330 170 330 211
a 0 up 33 0 145 329 hct 100 V=
s 120 390 140 390 185
s 120 380 120 390 199
s 80 380 120 380 197
s 120 330 120 340 207
s 120 340 120 380 820
s 80 340 120 340 205
s 120 420 120 390 947
w 824
a 0 up 0:33 0 0 0 hln 100 V=
s 730 460 670 460 565
a 0 up 33 0 715 459 hct 100 V=
w 234
a 0 up 0:33 0 0 0 hln 100 V=
s 360 460 330 460 1014
a 0 up 33 0 340 459 hct 100 V=
w 693
a 0 up 0:33 0 0 0 hln 100 V=
s 450 330 450 340 1130
a 0 up 33 0 452 360 hlt 100 V=
s 450 340 450 390 1137
s 450 340 490 340 1122
w 1150
a 0 up 0:33 0 0 0 hln 100 V=
s 570 500 570 430 1151
a 0 up 33 0 572 465 hlt 100 V=
w 231
a 0 up 0:33 0 0 0 hln 100 V=
s 450 420 450 430 501
a 0 up 33 0 452 430 hlt 100 V=
s 450 430 450 500 1095
w 694
a 0 up 0:33 0 0 0 hln 100 V=
s 570 390 570 340 1184
a 0 up 33 0 572 415 hlt 100 V=
s 530 340 530 350 1185
s 570 340 570 330 1189
s 530 340 570 340 1178
w 1104
a 0 up 0:33 0 0 0 hln 100 V=
s 500 410 500 440 1116
s 500 410 490 410 1103
s 490 410 470 410 1134
s 490 380 490 410 1125
a 0 up 33 0 492 395 hlt 100 V=
w 229
a 0 up 0:33 0 0 0 hln 100 V=
s 400 460 480 460 1119
a 0 up 33 0 400 459 hct 100 V=
w 507
a 0 up 0:33 0 0 0 hln 100 V=
s 550 460 630 460 1171
a 0 up 33 0 620 459 hct 100 V=
w 663
a 0 up 0:33 0 0 0 hln 100 V=
s 510 550 530 550 869
s 500 550 510 550 1112
s 570 550 570 540 517
s 500 480 500 550 1105
s 450 550 450 540 1160
s 450 550 500 550 515
a 0 up 33 0 535 549 hct 100 V=
s 530 550 570 550 1170
s 530 480 530 550 1168
w 1165
a 0 up 0:33 0 0 0 hln 100 V=
s 550 410 530 410 1164
s 530 410 530 440 1166
a 0 up 33 0 532 425 hlt 100 V=
s 530 390 530 410 1174
w 377
a 0 up 0:33 0 0 0 hln 100 V=
s 50 180 80 180 1030
a 0 up 33 0 60 179 hct 100 V=
@junction
j 340 150
+ p 55 1
+ s 77
j 130 220
+ p 6 1
+ s 25
j 40 340
+ p 190 1
+ s 193
j 40 380
+ p 191 1
+ s 194
j 40 420
+ p 192 1
+ s 195
j 880 170
+ p 159 1
+ s 179
j 910 170
+ p 159 2
+ w 163
j 720 330
+ p 237 1
+ s 256
j 1000 470
+ p 288 -
+ s 290
j 1000 430
+ p 288 +
+ s 292
j 1040 430
+ p 289 -
+ s 293
j 1040 470
+ p 289 +
+ s 291
j 930 500
+ s 271
+ w 831
j 950 490
+ p 262 2
+ w 831
j 870 330
+ p 238 2
+ w 328
j 920 380
+ s 259
+ w 253
j 810 330
+ p 238 1
+ w 243
j 760 330
+ p 237 2
+ w 243
j 870 320
+ s 254
+ w 543
j 80 420
+ p 192 2
+ w 944
j 120 380
+ w 944
+ w 944
j 120 340
+ w 944
+ w 944
j 970 210
+ s 158
+ w 152
j 980 170
+ w 154
+ w 154
j 1110 190
+ s 180
+ w 172
j 520 170
+ s 78
+ w 65
j 380 190
+ s 70
+ w 84
j 380 150
+ p 55 2
+ w 73
j 390 150
+ w 73
+ w 73
j 170 70
+ p 7 1
+ w 294
j 130 180
+ p 6 2
+ w 13
j 120 180
+ p 5 2
+ w 13
j 210 70
+ p 7 2
+ w 460
j 250 150
+ s 43
+ w 460
j 800 200
+ s 137
+ w 124
j 670 220
+ s 129
+ w 128
j 730 140
+ s 102
+ w 911
j 680 180
+ w 913
+ w 913
j 910 490
+ p 261 2
+ w 831
j 930 170
+ p 160 1
+ w 163
j 970 170
+ p 160 2
+ w 154
j 1060 100
+ p 161 2
+ w 172
j 1020 100
+ p 161 1
+ w 154
j 620 180
+ p 104 1
+ s 461
j 660 180
+ p 104 2
+ w 913
j 430 70
+ p 56 1
+ w 73
j 470 70
+ p 56 2
+ w 65
j 760 60
+ p 105 2
+ w 124
j 760 100
+ p 106 2
+ w 124
j 800 100
+ w 124
+ w 124
j 720 60
+ p 105 1
+ w 913
j 730 100
+ p 106 1
+ w 913
j 680 100
+ w 913
+ w 913
j 80 180
+ p 5 1
+ w 377
j 180 190
+ p 931 V+
+ s 44
j 180 130
+ p 931 V-
+ s 45
j 220 160
+ p 931 OUT
+ w 460
j 140 180
+ p 931 +
+ w 13
j 140 140
+ p 931 -
+ w 294
j 440 200
+ p 932 V+
+ s 54
j 440 140
+ p 932 V-
+ s 53
j 400 150
+ p 932 -
+ w 73
j 400 190
+ p 932 +
+ w 84
j 480 170
+ p 932 OUT
+ w 65
j 730 230
+ p 933 V+
+ s 103
j 690 220
+ p 933 +
+ w 128
j 730 170
+ p 933 V-
+ w 911
j 690 180
+ p 933 -
+ w 913
j 770 200
+ p 933 OUT
+ w 124
j 1030 220
+ p 934 V+
+ s 157
j 1030 160
+ p 934 V-
+ s 156
j 1070 190
+ p 934 OUT
+ w 172
j 990 170
+ p 934 -
+ w 154
j 990 210
+ p 934 +
+ w 152
j 180 440
+ p 935 V+
+ s 189
j 180 380
+ p 935 V-
+ s 188
j 120 430
+ s 219
+ w 182
j 140 430
+ p 935 +
+ w 182
j 170 330
+ p 196 1
+ w 944
j 80 380
+ p 191 2
+ w 944
j 80 340
+ p 190 2
+ w 944
j 140 390
+ p 935 -
+ w 944
j 120 390
+ w 944
+ w 944
j 210 330
+ p 196 2
+ w 214
j 260 410
+ s 222
+ w 214
j 220 410
+ p 935 OUT
+ w 214
j 130 70
+ w 294
+ w 294
j 90 70
+ p 960 2
+ w 294
j 50 70
+ s 692
+ p 960 1
j 930 400
+ s 309
+ w 318
j 950 450
+ p 262 1
+ w 318
j 930 450
+ w 318
+ w 318
j 910 460
+ p 261 1
+ w 318
j 1040 330
+ p 241 2
+ s 255
j 1040 320
+ p 241 1
+ s 250
j 1000 330
+ p 241 4
+ w 336
j 1000 320
+ p 241 3
+ w 543
j 930 330
+ p 257 2
+ w 336
j 920 330
+ p 257 1
+ w 328
j 920 370
+ p 257 3
+ w 253
j 930 370
+ p 257 4
+ w 318
j 930 400
+ p 1022 pin1
+ s 309
j 930 400
+ p 1022 pin1
+ w 318
j 670 460
+ p 504 2
+ w 824
j 730 460
+ s 696
+ w 824
j 450 430
+ p 1093 c
+ w 231
j 330 460
+ s 695
+ w 234
j 450 330
+ s 232
+ w 693
j 450 390
+ p 1093 e
+ w 693
j 450 340
+ w 693
+ w 693
j 490 340
+ p 1121 2
+ w 693
j 570 500
+ p 514 2
+ w 1150
j 570 430
+ p 1139 c
+ w 1150
j 570 390
+ p 1139 e
+ w 694
j 570 330
+ s 509
+ w 694
j 530 350
+ p 1173 2
+ w 694
j 570 340
+ w 694
+ w 694
j 450 500
+ p 512 2
+ w 231
j 470 410
+ p 1093 b
+ w 1104
j 490 380
+ p 1121 1
+ w 1104
j 490 410
+ w 1104
+ w 1104
j 500 440
+ p 1203 C
+ w 1104
j 480 460
+ p 1203 B
+ w 229
j 550 460
+ p 1202 B
+ w 507
j 530 480
+ p 1202 E
+ w 663
j 530 440
+ p 1202 C
+ w 1165
j 630 460
+ p 504 1
+ w 507
j 550 410
+ p 1139 b
+ w 1165
j 530 390
+ p 1173 1
+ w 1165
j 530 410
+ w 1165
+ w 1165
j 510 550
+ s 236
+ w 663
j 570 540
+ p 514 1
+ w 663
j 450 540
+ p 512 1
+ w 663
j 500 550
+ w 663
+ w 663
j 530 550
+ w 663
+ w 663
j 500 480
+ p 1203 E
+ w 663
j 50 180
+ p 1204 pin1
+ w 377
j 360 460
+ p 224 1
+ w 234
j 400 460
+ p 224 2
+ w 229
j 50 220
+ p 2 -
+ s 24
j 50 180
+ p 2 +
+ w 377
j 50 180
+ p 1204 pin1
+ p 2 +
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=B
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
t 842 t 6 370 260 480 290 0 25
Proportional stage (U2)

t 841 t 6 190 290 90 260 0 33
Error / difference amplifier (U1)
t 866 t 6 990 260 1110 290 0 21
Derivative stage (U4)
t 867 t 6 90 490 190 520 0 22
Summing amplifier (U5)
t 872 t 6 790 530 1070 550 0 50
 Motor R-L-E branch and mechanical analog (E1, F1)
t 843 t 6 660 270 780 300 0 22
 Integral stage (U3)

t 871 t 6 430 580 570 600 0 18
Power stage driver
